function v = velocity(theta0,r,l,e,w0,a,tt)
syms t
theta = theta0 + w0*t + 0.5*a*t^2;   %Value of crank angle at time t
w = w0 + a*t;  %Value of crank angle at time t

phi = asin((r*sin(theta)-e)/l);   %Value of coupler angle at time t
phi_dot = (r*cos(theta)*w)/(l*cos(phi));  %Value of coupler angular velocity at time t

v = -(r*sin(theta)*w + l*sin(phi)*phi_dot); %Value of slider velocity at time t

plot(tt,double(subs(v,tt)));   % graph of slider velocity versus time 
title('Plot of Slider Velocity')
xlabel('Time (s)')
ylabel('Velocity')
legend('Velocity in X-direction')
grid on
grid minor