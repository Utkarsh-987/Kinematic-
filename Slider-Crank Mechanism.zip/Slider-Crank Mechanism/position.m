function [s, theta, phi,tt] = position(r,l,e,theta0,w,a)
syms t
theta = theta0 + w*t + 0.5*a*t^2; %Value of crank angle at time x
phi = asin((r*sin(theta)-e)/l);  %Value of coupler angle at time x
s = r*cos(theta) + l*cos(phi);  %Distance of slider from origin

eq = theta-theta0 == 2*pi;
ii=solve(eq,t);      % time at which crank rotates an angle of 2*pi
if length(ii) ==2
    tt = 0:0.001:ii(2);
else
    tt = 0:0.001:ii;
end 

% graph of slider position versus time 
plot(tt,subs(s ,tt));
title('Plot of Slider Position')
xlabel('Time (s)')
ylabel('Position')
legend('Position in X-direction')
grid on
grid minor

