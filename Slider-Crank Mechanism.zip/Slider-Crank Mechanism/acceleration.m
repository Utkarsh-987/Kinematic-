function accel = acceleration(theta0,r,l,w,e,a,tt)
syms t
theta = theta0 + w*t + 0.5*a*t^2;   %Value of crank angle at time t
  
phi = asin((r*sin(theta)-e)/l);    %Value of coupler angle at time t
phidot = diff(phi);         %Value of coupler angular velocity at time t
phi_doubledot = diff(phidot);    %Value of coupler angular acceleration at time t

%value of slider acceleratiion
accel = -(r*cos(theta)*(w^2) + r*sin(theta)*a + l*sin(phi)*phi_doubledot + l*cos(phi)*(phidot^2));
plot(tt,double(subs(accel,tt)));   % graph of slider accleration versus time 
title('Plot of Slider Acceleration')
xlabel('Time (s)')
ylabel('Acceleration')
grid on
grid minor