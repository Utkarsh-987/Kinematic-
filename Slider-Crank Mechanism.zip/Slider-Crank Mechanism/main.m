% Inputs
r = input('Enter the length of the input/crank');
l = input('Enter the length of the connecting rod');
e = input('Enter the length of the offset(upward is positive)');   
theta0 = input('Enter the initial angle(in radians) of the input link');
w =input('Enter the angular velocity(in rad/s) of the input link');
a =input('Enter the angular acceleratiion of the input link');
% Check if it is slider crank or not
if r+e>l
    error('Invalid link lengths for slider-crank mechanism ')
end 

%Plot of slider position
figure(1) 
[s, theta, phi,tt] = position(r,l,e,theta0,w,a);

%Plot of slider velocity
figure(2) 
v = velocity(theta0,r,l,e,w,a,tt);

%Plot of slider acceleration
figure(3); 
acceleration(theta0,r,l,w,e,a,tt);

%Animation
for ii = 0:0.05:tt(end)
    A = [r*cos(subs(theta,ii)), r*sin(subs(theta,ii))];
    figure(4)
    slider = plot([subs(s,ii)-r/5,subs(s,ii)+r/5],[e,e],'Linewidth',8,'Color','b');
    hold on;
    hr = plot([0, A(1)],[0, A(2)], 'Color','g');
    hold on;   
    hl = plot([A(1), subs(s,ii)], [A(2), e],  Color='m');
    hold on;
    hcir1 = plot(0,0, 'ro','LineWidth',1.5,'MarkerSize',1.5);
    hold on;
    hcir2 = plot(A(1),A(2), 'ro','LineWidth',1.5,'MarkerSize',1.5);
    hold on;
    hcir3 = plot(subs(s,ii),e, 'ro','LineWidth',1.5,'MarkerSize',1.5);
    axis([-r-r,r+l+r, -l,l]);
    title('Animation of Slider-Crank Mechanism','FontSize',15,Color='b');
    legend('Slider','Crank','Connecting rod');
    hold off;
end
