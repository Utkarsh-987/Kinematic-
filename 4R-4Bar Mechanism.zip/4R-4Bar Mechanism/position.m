function [theta, phi, rin, rfl,tt]  = position(lin, lco, lfr, lfl, theta0, w0,alpha) 
syms t
theta = theta0 + w0*t + 0.5*alpha*t^2; % crank angle at any time t

eq = theta-theta0 == 2*pi;
ii=solve(eq,t);      % ii is the time at which crank rotates an angle of 2*pi

if length(ii) == 2
    tt = 0:0.01:ii(2);
else
    tt = 0:0.01:ii;
end

a = sin(theta);
b = cos(theta) - lfr/lin ;
c = (lin^2 + lfr^2 + lfl^2 - lco^2)/(2*lin*lfl) -(lfr/lfl)*cos(theta);
% phi is the follwer angle
phi = 2*atan((a-sqrt(a^2 + b^2 -c^2))/ (b+c)); 
rin = [lin*cos(theta), lin*sin(theta)]; % position of endpoints of crank
rfl = [lfr+lfl*cos(phi), lfl*sin(phi)];   % position of endpoints of follower

% Graph of follower position
px = subs(rfl(1), tt);
py = subs(rfl(2), tt);
plot(tt,px,tt,py);

title('Plot of Follower Position')
xlabel('Time (s)')
ylabel('Value')
legend('X-dir','Y-dir')
grid on
grid minor