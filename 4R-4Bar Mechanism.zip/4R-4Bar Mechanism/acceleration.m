function acceleration(w0,a0,rfl,lfr,phi,tt)
syms t
win = w0+a0*t; %angular acceleration of crank
alpha_fl = diff(phi,2); %angular acceleration of follower

% linear acceleration of follower
afl = [-rfl(2)*alpha_fl, (rfl(1)-lfr)*alpha_fl] - (win^2)*rfl;

% Graph of Follower Acceleration
ax = subs(afl(1), tt);
ay = subs(afl(2), tt);
plot(tt,ax,tt,ay);
title('Plot of Follower Acceleration')
xlabel('Time (s)')
ylabel('Value')
legend('X-dir','Y-dir')
grid on
grid minor