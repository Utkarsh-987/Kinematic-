function  velocity(theta, phi, rin ,rfl,lfr,tt)
syms t
wfl = diff(phi); %angular velocity of follower
win = diff(theta); %angular velocity of crank
vin = [-rin(2)*win, rin(1)*win]; %linear velocity of crank
vfl = [-rfl(2)*wfl, (rfl(1)-lfr)*wfl]; %linear velocity of follower

% Graph of Follower Velocity
vx = subs(vfl(1), tt);
vy = subs(vfl(2), tt);
plot(tt,vx,tt,vy);

% Graph of Follower Velocity
title('Plot of Follower Velocity')
xlabel('Time (s)')
ylabel('Value')
legend('X-dir','Y-dir')
grid on
grid minor
