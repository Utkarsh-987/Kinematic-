lin = input('Enter the length of the input/crank');
lco = input('Enter the length of the coupler');
lfr = input('Enter the length of the frame');
lfl = input('Enter the length of the follower');

theta0 = input('Enter the initial angle(in radians) of the input link');
w0 = input('Enter the angular velocity(in rad/s) of the input link');
a0 = input('Enter the acceleration of the input link');
% Check if mechanism is crank-rocker or not
s = min([lin, lfl, lco, lfr]);
l = max([lin, lfl, lco, lfr]);
if 2*(l+s) > lin+lfl+lco+lfr
    error('It is not a grasofian mechanism')
elseif lin ~= s
    error('It is not a crank-rocker mechanism')
end
% positon analusis
figure(1);
[theta, phi, rin, rfl,tt] = position(lin, lco, lfr, lfl, theta0, w0,a0);
% velocity analusis
figure(2);
velocity(theta,phi,rin,rfl,lfr,tt);
% acceleration analusis
figure(3);
acceleration(w0,a0,rfl,lfr,phi,tt);

% Animation
for ii = 0:0.1:tt(end)
    figure(4);
    rin1 = subs(rin(1),ii);
    rin2 = subs(rin(2),ii);
    rfl1 = subs(rfl(1),ii);
    rfl2 = subs(rfl(2),ii);
    plot([0 lfr], [0 0], 'r', 'LineWidth',5);
    hold on;
    plot([0 rin1],[0 rin2], 'c', 'LineWidth',4);
    hold on;
    plot([lfr rfl1],[0 rfl2], 'k', 'LineWidth',4);
    hold on;
    plot([rin1 rfl1],[rin2 rfl2], 'y', 'LineWidth',4);
    hold on;
    title('Animation of 4R-4Bar mechanism','FontSize',15,Color='b');
    legend('Frame','Input','Follower','Coupler');
    axis([-lin, lin+lfr, -l, l]);
    hold off;
end