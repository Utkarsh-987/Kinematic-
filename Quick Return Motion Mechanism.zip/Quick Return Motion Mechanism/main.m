% Taking Input
l1 = input('Enter the distance between hinge point of the crank and that of the slotted bar');
l2 = input('Enter the length of the crank');
l3 = input('Enter the length of the slotted bar');
l4 = input('Enter the length of the connecting rod');
l5 = input('Enter the distance of the ram from the hinge point of crank');

theta0 = input('Enter the initial angle(in rad) of the crank');
w0 = input('Enter the angular velocity(in rad/s) of the crank');
a0 = input('Enter the angular acceleration of the crank');
% position analysis
figure(1)
[theta,theta4,theta5,s6,tt] = position(l1,l2,l3,l4,l5,theta0,w0,a0);
% velocity analysis
figure(2)
velocity(theta4,s6,tt);
% acceleration analysis
figure(3)
acceleration(s6,tt);

% animation
for ii = 1:0.05:3
    th = subs(theta,ii);
    th4 = subs(theta4,ii); 
    figure(4)
    A = [l2*cos(th), l1+l2*sin(th)];
    B = [l3*cos(th4), l3*sin(th4)];
    C = [subs(s6,ii), l1+l5];
    slider1 = plot([C(1)-l2/2,C(1)+l2/2],[l1+l5,l1+l5],'Linewidth',20,'Color','b');
    hold on;
    hl2 = plot([0,A(1)], [l1,A(2)], 'LineWidth',5,'Color','g' );   
    hold on;
    hl4 = plot([0,B(1)], [0,B(2)], 'LineWidth', 5 ,'Color','y');
    hold on;
    slider2 = plot([A(1)-B(1)*(l2/(3*l3)), A(1)+B(1)*(l2/(3*l3))],[A(2)-B(2)*(l2/(3*l3)),A(2)+B(2)*(l2/(3*l3))], 'Linewidth',20,'Color','b');
    hold on;
    hl5 = plot([B(1),C(1)],[B(2),C(2)] , 'LineWidth',5,'Color','m');
    hold on;
    plot(A(1),A(2), 'ro','LineWidth',5.5,'MarkerSize',5.5);
    hold on;
    plot(B(1),B(2), 'ro','LineWidth',5.5,'MarkerSize',5.5);
    hold on;
    plot(C(1),C(2), 'ro','LineWidth',5.5,'MarkerSize',5.5);
    hold on;
    plot(0,l1,'ks','LineWidth',15,'MarkerSize',15);
    hold on;
    plot(0,0, 'ks','LineWidth',15,'MarkerSize',15); 
    hold on;
    plot(0,l1,'ro','LineWidth',5.5,'MarkerSize',5.5);
    hold on;
    plot(0,0, 'ro','LineWidth',5.5,'MarkerSize',5.5);   
    title('Animation of Quick Return Motion Mechanism','FontSize',15,Color='b');
    axis([-l3,l3, 0,l1+l5+2]);
    axis(gca,'equal');
    pause(0.001);
    hold off;   
end


