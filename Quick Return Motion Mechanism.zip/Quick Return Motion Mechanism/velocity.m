function velocity(theta4,s6,tt)
wr = diff(theta4); % rocker angular velocity
v = diff(s6);
% Graph of cutting-blade velocity
plot(tt,subs(v,tt));
grid on
grid minor
title('Plot of Cutting-Blade Velocity')
xlabel('Time (s)')
ylabel('Value')
legend('X-dir Velocity')

