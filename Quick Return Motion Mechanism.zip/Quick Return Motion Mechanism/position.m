function [theta,theta4,theta5,s6,tt] = position(l1,l2,l4,l5,l6,theta0,w0,a0)
syms t;
theta = theta0 + w0*t + 0.5*a0*t^2;
eq = theta-theta0 == 2*pi;
ii=solve(eq,t);      % ii is the time at which crank rotates an angle of 2*pi

if length(ii) == 2
    tt = 0:0.005:ii(2);
else
    tt = 0:0.005:ii;
end
s4 = sqrt(l1^2 + l2^2 + 2*l1*l2*sin(theta));
theta4 = acos((l2*cos(theta))/(s4));
theta5 = asin(-(l2*sin(theta)+ (l4-s4)*sin(theta4) - l6)/l5);
s6 =  l2*cos(theta) + l5*cos(theta5) + (l4-s4)*cos(theta4);

% Graph of cutting-blade position
plot(tt,subs(s6,tt))
grid on
grid minor
title('Plot of Cutting-Blade Position')
xlabel('Time (s)')
ylabel('Value')
legend('X-dir Position')
