function acceleration(s6,tt)
a = diff(s6,2);
% Graph of cutting-blade acceleration
plot(tt,subs(a,tt))
grid on
grid minor
title('Plot of Cutting-Blade Acceleration')
xlabel('Time (s)')
ylabel('Value')
legend('X-dir Acceleration')
